#include "pch.h"
#include "gtest/gtest.h"
#include "C:/myProject/GroceyStoreManagement/Store/Product.h"
#include "C:/myProject/GroceyStoreManagement/Store/Product.cpp"
#include "C:/myProject/GroceyStoreManagement/Store/Source.cpp"
#include "C:/myProject/GroceyStoreManagement/Store/Supplier.cpp"
#include "C:/myProject/GroceyStoreManagement/Store/Supplier.h"


TEST(AddingItem, Add_1) {
}